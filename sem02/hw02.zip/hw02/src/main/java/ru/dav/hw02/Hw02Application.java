package ru.dav.hw02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hw02Application {

	public static void main(String[] args) {
		SpringApplication.run(Hw02Application.class, args);
	}

}
