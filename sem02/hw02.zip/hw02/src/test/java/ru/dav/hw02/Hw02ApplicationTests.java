package ru.dav.hw02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hw02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
